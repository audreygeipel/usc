import javax.swing.*;

public class Space extends MapObject {

  public Space(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }
}
