package cosmoshunter;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

import cosmoshunter.panels.*;

public class Application extends JFrame {

  // This is the instance of Game class
  public Game game;
  // CardLayout is used for managing panels
  public CardLayout card = new CardLayout();
  
  // This is the constructor function of Application class
  // Sets the main frame
  // Sets the layout and adds panels to it
  public Application(){
    game = new Game(this);

    setSize(700, 500);
    setTitle("Cosmos Hunter - The best game");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(card);

    add("game", new GamePanel(this));
    add("menu", new MenuPanel(this));
    add("player", new PlayerPanel(this));
    add("scores", new ScoresPanel(this));
    add("info", new WorldInfoPanel(this));
  }

  // This is the main function of this app
  // Creates instance off Application class
  public static void main(String[] argv){
    Application app = new Application();
    app.showMenu();
    app.setVisible(true);
  }

  // This function shows the main game panel
  public void showGame(){
    card.show(getContentPane(), "game");
    game.start();
  }

  // This function shows the level/Galaxy information panel
  public void showGalaxyInfo(){
    card.show(getContentPane(), "info");
  }

  // This function shows the player panel which asks for username
  public void showPlayer(){
    card.show(getContentPane(), "player");
  }

  // This function shows the scores panel
  public void showScores(){
    card.show(getContentPane(), "scores");
  }

  // This function shows the menu panel 
  public void showMenu(){
    card.show(getContentPane(), "menu");
  }

  // This function quits the application
  public void quit(){
    setVisible(false);
    dispose();
  }
}
