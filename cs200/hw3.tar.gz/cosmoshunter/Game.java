package cosmoshunter;

import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;

import cosmoshunter.galaxies.*;
import cosmoshunter.entities.*;

public class Game {
  // this is the instance of Application class
  public Application app;
  // This is the current galaxy/level
  public AbstractGalaxy galaxy;
  // This is instance of Player class
  public Player player;
  // This variable stores the highscores
  public TreeMap<Integer, String> scores = new TreeMap<Integer, String>(Collections.reverseOrder());
  public javax.swing.Timer timer;
  public int timerSpeed = 775;

  // Constructor class of Game class
  // Creates player and galaxy
  // Also reads highscores
  public Game(Application a){
    app = a;
    player = new Player(this, 0, 5);
    galaxy = new BlackEyeGalaxy(this);
    timer = new javax.swing.Timer(timerSpeed, new TimeListener());
    loadScores();
  }

  // This function starts or resumes the game
  public void start(){
    if (this.isNew()) 
      app.showPlayer();
    else
      timer.start();
  }

  // This function is called by InputHandler
  // This function is called everytime user presses a key
  // This is basically 1 round of the game
  // It moves player
  // It tells galaxy class to tick all the objects
  // and repaints the GamePanel
  public void tick(String cmd){
    if (cmd.equals("timer")){
      player.tick("r");
      galaxy.tick();
    } else {
      player.tick(cmd);
    }

    if(player.isDead()){
      quit();
    } else if (galaxy.isComplete()) {
      galaxy = galaxy.getNextGalaxy();
      app.repaint();
      app.showGalaxyInfo();
    } else {
      app.repaint();
    }
  }

  public void stop(){
    app.showMenu();
    timer.stop();
  }

  // This function saves the highscores, and quits the app
  public void quit(){
    stop();
    scores.put(player.getScore(), player.name);
    saveScores();
    app.showMenu();
    app.quit();
  }

  // This function checks if game is new
  public boolean isNew(){
    return (player.name.equals(""));
  }

  // This function reads the highscores data from save file
  public void loadScores(){
    try {
      FileInputStream fis = new FileInputStream("scores.dat");
      ObjectInputStream ois = new ObjectInputStream(fis);
      try {
        scores = (TreeMap<Integer, String>)ois.readObject();
      } catch (ClassNotFoundException ex) {
        // System.out.println("Class not founf exception");
      }
    } catch (IOException ex) {
      // System.out.println("IO Exception");
    }
  }

  // This function saves the highscores of the game to a file
  public void saveScores(){
    try {
      FileOutputStream fos = new FileOutputStream("scores.dat");
      try {
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(scores);
      } catch (IOException ex) {
        System.out.println("IO Exception");
      }
    } catch (FileNotFoundException ex) {
      System.out.println("File not found excepton");
    }
  }

  // This function reads the game data from save file
  public boolean load(){
    try {
      FileInputStream fis = new FileInputStream("game.dat");
      ObjectInputStream ois = new ObjectInputStream(fis);
      try {

        player.score = (Integer)ois.readObject();
        player.bullet = (Integer)ois.readObject();
        player.energy = (Integer)ois.readObject();
        player.name = (String)ois.readObject();
        player.galaxyID = (Integer)ois.readObject();
        switch (player.galaxyID) {
          case 1:
            galaxy = new BlackEyeGalaxy(this);
            break;
          case 2:
            galaxy = new AndromedaGalaxy(this);
            break;
          case 3:
            galaxy = new MilkyWayGalaxy(this);
            break;
        }
        player.x = (Integer)ois.readObject();
        player.y = (Integer)ois.readObject();
        galaxy.extendMap(player.x + galaxy.frame_width);
        return true;

      } catch (ClassNotFoundException ex) {
        // System.out.println("Class not founf exception");
      }
    } catch (IOException ex) {
      // System.out.println("IO Exception");
    }
    return false;
  }

  // This function saves the current state of the game to a file
  // We store map and players info on game.dat file
  public boolean save(){
    try {
      FileOutputStream fos = new FileOutputStream("game.dat");
      try {
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        oos.writeObject(player.score);
        oos.writeObject(player.bullet);
        oos.writeObject(player.energy);
        oos.writeObject(player.name);
        oos.writeObject(player.galaxyID);
        oos.writeObject(player.x);
        oos.writeObject(player.y);
        return true;
      } catch (IOException ex) {
        System.out.println("IO Exception");
      }
    } catch (FileNotFoundException ex) {
      System.out.println("File not found excepton");
    }
    return false;
  }

  class TimeListener implements ActionListener {
    public void actionPerformed(ActionEvent ae){
      tick("timer");
      if (timerSpeed > 700) timerSpeed = timerSpeed - 2;
      timer.setDelay(timerSpeed);
    }
  }
}
