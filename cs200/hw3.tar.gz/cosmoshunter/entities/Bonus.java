package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Bonus extends AbstractEntity {

  // This is the constructor function of Bonus class
  public Bonus(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent Bonus in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/bonus.gif");
  }

  // This function is called everytime player moves
  // It moves randomly up or down
  // If it encounters player, it increases player's score
  public void tick(){
    int rint = game.galaxy.generator.nextInt(3);

    if (rint == 1 && y > 0 && game.galaxy.isEntityAt(x, y-1, "Space")){
      game.galaxy.swapEntities(x, y, x, y-1);
    } else if (rint == 2 && y < (game.galaxy.height-1) && game.galaxy.isEntityAt(x, y+1, "Space")){
      game.galaxy.swapEntities(x, y, x, y+1);
    }

    if (isPlayerHere()){
      game.player.score = game.player.score + 150;
    }
  }
}

