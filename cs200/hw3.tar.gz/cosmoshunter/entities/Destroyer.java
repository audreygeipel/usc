package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Destroyer extends AbstractEntity {

  public Destroyer(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent destroyer in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/destroyer.gif");
  }

  // This function is called everytime player moves
  // It moves up or down
  // If it moves it gets closer to player
  // If encounters player, it kills him
  public void tick(){
    int rint = game.galaxy.generator.nextInt(100);

    if (game.player.y == y || rint < 60) {
    
    } else if (game.player.y == y || rint < 75) {
      shoot();    
    } else if (game.player.y < y && game.galaxy.isEntityAt(x, y-1, "Space")){
      game.galaxy.swapEntities(x, y, x, y-1);
    } else if (game.player.y > y && game.galaxy.isEntityAt(x, y+1, "Space")){
      game.galaxy.swapEntities(x, y, x, y+1);
    }

    if (isPlayerHere()){
      game.player.kill();
    }
  }

  // This function shoots DestroyerRocket
  public void shoot(){
    DestroyerRocket newRocket = new DestroyerRocket(game, x-1, y);
    game.galaxy.placeEntityAt(x-1, y, newRocket);
  }
}

