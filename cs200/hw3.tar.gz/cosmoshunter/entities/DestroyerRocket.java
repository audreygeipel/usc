package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class DestroyerRocket extends AbstractEntity {

  public DestroyerRocket(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent DestroyerRocket in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/destroyer-rocket.gif");
  }

  // This function called everytime player moves
  // Goes forward faster than other objects
  public void tick(){
    if (game.player.y == y) {
      forward();
    } else if(game.player.y < y) {
      up();
      forward();
    } else {
      down();
      forward();
    }

    if (isPlayerHere()) {
      game.player.hurt(25);
    }
  }

  // This moves DestroyerRocket down
  public void down(){
    if (game.galaxy.isEntityAt(x, y+1, "Space")){
      game.galaxy.swapEntities(x, y, x, y+1);
    } else {
      forward();
    }
  }

  // this move DestroyerRocket up
  public void up(){
    if (game.galaxy.isEntityAt(x, y-1, "Space")){
      game.galaxy.swapEntities(x, y, x, y-1);
    } else {
      forward();
    }
  }

  // It moves if there is nothing front of it
  // If there is another object, it destroys both objects
  public void forward(){
    if (game.galaxy.isEntityAt(x-1, y, "Space")){
      game.galaxy.swapEntities(x, y, x-1, y);
    } else {
      game.galaxy.placeEntityAt(x, y, new Space(game, x, y));
      game.galaxy.placeEntityAt(x-1, y, new Space(game, x-1, y));
    }
  }
}

