package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Enemy extends AbstractEntity {

  public Enemy(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent Enemy in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/enemy.gif");
  }

  // This function is called everytime player moves
  // It moves up or down
  // If it moves it gets closer to player
  // If encounters player, it kills him
  public void tick(){
    int rint = game.galaxy.generator.nextInt(100);

    if (game.player.y == y || rint < 50) {
    
    } else if (game.player.y < y && game.galaxy.isEntityAt(x, y-1, "Space")){
      game.galaxy.swapEntities(x, y, x, y-1);
    } else if (game.player.y > y && game.galaxy.isEntityAt(x, y+1, "Space")){
      game.galaxy.swapEntities(x, y, x, y+1);
    }

    if (isPlayerHere()){
      game.player.kill();
    }
  }
}

