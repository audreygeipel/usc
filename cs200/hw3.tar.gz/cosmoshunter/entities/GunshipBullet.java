package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class GunshipBullet extends AbstractEntity {

  public GunshipBullet(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent GunshipBullet in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/gunship-bullet.gif");
  }

  // This function called everytime player moves
  // Goes forward faster than other objects
  public void tick(){
    forward();

    if (isPlayerHere()) {
      game.player.hurt(15);
    }
  }

  // It moves if there is nothing front of it
  // If there is another object, it destroys both objects
  public void forward(){
    if (game.galaxy.isEntityAt(x-1, y, "Space")){
      game.galaxy.swapEntities(x, y, x-1, y);
    } else {
      game.galaxy.placeEntityAt(x, y, new Space(game, x, y));
      game.galaxy.placeEntityAt(x-1, y, new Space(game, x-1, y));
    }
  }
}

