package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Player extends AbstractEntity {
  public String name = "";
  // This var stores players score
  public int score = 0;
  // This is the remaining bullets of user
  public int bullet = 3;
  // This is player's remaining energy
  public int energy = 100;
  public int galaxyID;

  public Player(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent Player in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/spaceship.gif");
  }

  // This is called everytime user presses a key
  // Player moves based on the key
  public void tick(String key){
    if (key.equals("u")){
      up();
    } else if (key.equals("d")) {
      down();
    } else if (key.equals("r")) {
      forward();
    } else if (key.equals("space")) {
      shoot();
    }
  }

  // This returns the score of the user
  public int getScore(){
    return score + (x*10);
  }

  // This fires a bullet
  public boolean shoot(){
    if (bullet < 1) return false;
    Bullet newBullet = new Bullet(game, x, y);
    game.galaxy.placeEntityAt(x, y, newBullet);
    newBullet.forward();
    bullet--;
    return true;
  }

  // This function moves player down
  public void down(){
    if (y < 9 && game.galaxy.isEntityAt(x, y+1, "Space"))
      y++;
  }

  // This function moves player up
  public void up(){
    if (y > 0 && game.galaxy.isEntityAt(x, y-1, "Space"))
      y--;
  }

  // This function moves player forward
  public void forward(){
    if (x != game.galaxy.width) x++;
  }

  // This decreases user's energy
  public void hurt(int damage){
    energy = energy - damage;
  }

  // This kills the player
  public void kill(){
    energy = 0;
  }

  // This checks if the player is dead
  public boolean isDead(){
    return energy <= 0;
  }
}

