package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Power extends AbstractEntity {

  public Power(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }

  // This is used to represent Power in GUI
  public JLabel getLabel(){
    return super.getLabel("imgs/power.gif");
  }

  // This function is called everytime player moves
  // increases player's energy
  public void tick(){
    if (isPlayerHere()){
      game.player.energy = game.player.energy + 20;
    }
  }
}

