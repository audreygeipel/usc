package cosmoshunter.entities;

import javax.swing.*;

import cosmoshunter.*;

public class Space extends AbstractEntity {

  public Space(Game g, int loc_x, int loc_y){
    super(g, loc_x, loc_y);
  }
}
