package cosmoshunter.galaxies;

import java.util.*;

import cosmoshunter.*;
import cosmoshunter.entities.*;

public abstract class AbstractGalaxy {
  // This is the instance of Game class
  public Game game;
  // This var stores the height of the galax
  public int height = 10;
  // This var stores the width of the galaxy
  public int width = 0;
  // This is the width of the GUI frame
  public int frame_width = 20;
  // This is used to generate random numbers
  public Random generator;
  // This stores all the MapObjects on the map
  public ArrayList<AbstractEntity> entities = new ArrayList<AbstractEntity>(); 
  // This is the text that showed between levels
  public String info = "New Level";

  // This is the main function of galaxy
  // Also extends the map
  public AbstractGalaxy(Game g, int seed, int playerX, int playerY, int galaxyID){
    game = g;
    generator = new Random(seed);
    extendMap(frame_width + 10);

    //Save last worlds score
    game.player.score = game.player.getScore();

    game.player.x = playerX;
    game.player.y = playerY;
    game.player.galaxyID = galaxyID;
  }

  // This is called everytime player moves
  // This function calles tick function of every object in the map
  public void tick(){
    if (game.player.x + frame_width > width) extendMap(1);
    clearMap();

    for(int i=0; i < entities.size(); i++){
      if (entities.get(i).isInNow()) {
        entities.get(i).tick();
      }
    }        
  }

  // This extends map
  public abstract void extendMap(int num_columns);

  // This function checks if the game is completed
  public abstract boolean isComplete();

  // This function returns the next galax
  public abstract AbstractGalaxy getNextGalaxy();

  // This function sets backgrounf
  public abstract String getBackground();

  // This clears all the objects in the map which are in history
  public void clearMap(){
    for(int i=0; i < entities.size(); i++){
      if (entities.get(i).isInHistory()) {
        entities.remove(entities.get(i));
      }
    }        
  }

  // This function removes the object at x y and places the new object there
  public void placeEntityAt(int x, int y, AbstractEntity newEntity){
    entities.remove(getEntityAt(x, y));
    entities.add(newEntity);
  }

  // This checks the objects type at the given location
  public boolean isEntityAt(int x, int y, String entityName){
    for(int i=0; i < entities.size() ; i++){
      if (entities.get(i).x == x && entities.get(i).y == y) {
        if (entities.get(i).getClass().getName().equals("cosmoshunter.entities." + entityName)){
          return true;
        } 
      }
    }
    return false;    
  }
  
  // This returns the object at given location
  public AbstractEntity getEntityAt(int x, int y){
    for(int i=0; i < entities.size() ; i++){
      if (entities.get(i).x == x && entities.get(i).y == y) {
        return entities.get(i);
      }
    }        
    return entities.get(0); // TODO
  }

  // This swaps objects at given locations
  public void swapEntities(int x1, int y1, int x2, int y2){
    AbstractEntity object1 = getEntityAt(x1, y1);
    AbstractEntity object2 = getEntityAt(x2, y2);

    object1.x = x2;
    object1.y = y2;
    object2.x = x1;
    object2.y = y1;
  }
}

