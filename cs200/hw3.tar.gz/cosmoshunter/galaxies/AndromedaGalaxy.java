package cosmoshunter.galaxies;

import java.util.*;

import cosmoshunter.*;
import cosmoshunter.entities.*;

public class AndromedaGalaxy extends AbstractGalaxy { 

  // This is the second galaxy/level of the Game
  public AndromedaGalaxy(Game g){
    super(g, 29901004, 0, 2, 2);
    info = "You need to achive 3000 points to complete this new level.";
  } 

  // This extends map
  public void extendMap(int num_columns){
    for (int w = width; w < width + num_columns; w++){
      for (int h = 0; h < height; h++){
        int rint = generator.nextInt(100);

        if (rint < 10){
          entities.add(new Meteor(game, w, h));
        } else if (rint == 10) {
          entities.add(new Enemy(game, w, h));
        } else if (rint == 11) {
          entities.add(new Bonus(game, w, h));
        } else if (rint == 12) {
          entities.add(new Mine(game, w, h));
        } else if (rint == 13) {
          entities.add(new Gunship(game, w, h));
        } else {
          entities.add(new Space(game, w, h));
        }
      }
    }

    width = width + num_columns;
  }

  // this function checks if the game is complete
  public boolean isComplete(){
    return (game.player.getScore() > 3000); 
  }

  // This function returns the next galaxy
  public AbstractGalaxy getNextGalaxy(){
    return new MilkyWayGalaxy(game);
  }

  public String getBackground(){
    return "imgs/andromeda.gif";
  }
}

