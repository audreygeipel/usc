package cosmoshunter.galaxies;

import java.util.*;

import cosmoshunter.*;
import cosmoshunter.entities.*;

public class BlackEyeGalaxy extends AbstractGalaxy { 

  // This is the first level of the game
  public BlackEyeGalaxy(Game g){
    super(g, 19901004, 0, 5, 1);
    info = "You need to achive 1000 points to complete this new level.";
  } 

  // This extends map
  public void extendMap(int num_columns){
    for (int w = width; w < width + num_columns; w++){
      for (int h = 0; h < height; h++){
        int rint = generator.nextInt(100);

        if (rint < 10){
          entities.add(new Meteor(game, w, h));
        } else if (rint == 10) {
          entities.add(new Enemy(game, w, h));
        } else if (rint == 11) {
          entities.add(new Bonus(game, w, h));
        } else if (rint == 12) {
          entities.add(new Mine(game, w, h));
        } else {
          entities.add(new Space(game, w, h));
        }
      }
    }

    width = width + num_columns;
  }

  // This function checks if the level is complete
  public boolean isComplete(){
    return (game.player.getScore() > 1000); 
  }

  // This function returns the next level
  public AbstractGalaxy getNextGalaxy(){
    return new AndromedaGalaxy(game);
  }

  public String getBackground(){
    return "imgs/blackeye.png";
  }
}
