package cosmoshunter.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

abstract class AbstractPanel extends JPanel {

  public Application app;
  // this is the generic Container for JPanel
  public Container c = new Container();

  // this function sets the panel
  public AbstractPanel(Application a, int row, int column){
    app = a;

    setFocusable(true);
    setBackground(Color.BLACK);
    setLayout(new FlowLayout(FlowLayout.CENTER, 0, 125));

    c.setLayout(new GridLayout(row, column, 10, 5));

    add(c);
  }

  // this function draws the background
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    
    ImageIcon background = new ImageIcon("imgs/menu-background.jpg");
    g.drawImage(background.getImage() , 0, 0, null);
  }
}
