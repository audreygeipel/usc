package cosmoshunter.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

public class GamePanel extends JPanel{
  public Application app;
  public Game game;
  public JLabel info = new JLabel("Score", JLabel.CENTER);
  public Container galaxy = new Container();
  public ImageIcon background;

  public GamePanel(Application a){
    app = a;
    game = app.game;

    setLayout(new BorderLayout(0, 0));
    addKeyListener(new InputHandler());
    setFocusable(true);

    info.setForeground(Color.WHITE);
    galaxy.setLayout(new GridLayout(game.galaxy.height, game.galaxy.frame_width));

    add(galaxy, BorderLayout.CENTER);
    add(info, BorderLayout.SOUTH);
  }

  // this function draws the entities on this panel
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    
    requestFocus(true);

    background = new ImageIcon(game.galaxy.getBackground());
    g.drawImage(background.getImage(), -2*game.player.x, 0, null);

    info.setText("Score = " + game.player.getScore() + 
                 "    Energy = " + game.player.energy + 
                 "    Pos = (" + game.player.x + 
                            ", " + game.player.y +  ")" +
                 "    Bullet = " + game.player.bullet);

    galaxy.removeAll();
    for(int y=0; y < game.galaxy.height; y++){
      for(int x=game.player.x; x < game.player.x + game.galaxy.frame_width; x++){
        if (x == game.player.x && y ==game.player.y){
          galaxy.add(game.player.getLabel());
        } else {
          galaxy.add(game.galaxy.getEntityAt(x, y).getLabel());
        }
      }
    }
  } 

  class InputHandler implements KeyListener{

    public void keyPressed(KeyEvent e) {
      switch (e.getKeyCode()) {
        case KeyEvent.VK_DOWN: game.tick("d"); break;
        case KeyEvent.VK_UP: game.tick("u"); break;
        case KeyEvent.VK_LEFT: game.tick("l"); break;
        //case KeyEvent.VK_RIGHT: game.tick("r"); break;
        case KeyEvent.VK_ESCAPE: game.stop(); break;
        case KeyEvent.VK_SPACE: game.tick("space"); break;
      }
    }

    public void keyReleased(KeyEvent e) { }
    public void keyTyped(KeyEvent e) { }
  }
}
