package cosmoshunter.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

public class MenuPanel extends AbstractPanel {

  public JButton startGameB = new JButton("Start Game");
  public JButton scoresB = new JButton("High Scores");
  public JButton saveGameB = new JButton("Save Game");
  public JButton loadGameB = new JButton("Load Game");
  public JButton quitB = new JButton("Quit");
  public ButtonListener listener = new ButtonListener();
  public JLabel notif = new JLabel("Welcome", JLabel.CENTER);

  // This is the constructor of MenuPanel
  // This function adds JButtons to Container
  public MenuPanel(Application a){
    super(a, 6, 1);

    startGameB.addActionListener(listener);
    scoresB.addActionListener(listener);
    saveGameB.addActionListener(listener);
    loadGameB.addActionListener(listener);
    quitB.addActionListener(listener);
    notif.setForeground(Color.WHITE);

    c.add(notif);
    c.add(startGameB);
    c.add(scoresB);
    c.add(saveGameB);
    c.add(loadGameB);
    c.add(quitB);
  }

  // This is the custom action listener for this panel
  class ButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == startGameB){
        app.showGame();
        notif.setText("Welcome");
      } else if (e.getSource() == scoresB){
        app.showScores();
      } else if (e.getSource() == saveGameB){
        if (app.game.save()) notif.setText("Game is saved");
      } else if (e.getSource() == loadGameB){
        if (app.game.load()) 
          notif.setText("Game is loaded");
        else 
          notif.setText("No saved game");
      } else if (e.getSource() == quitB){
        app.quit();
      }
    }
  }
}
