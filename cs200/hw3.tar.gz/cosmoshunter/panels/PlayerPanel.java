package cosmoshunter.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

public class PlayerPanel extends AbstractPanel {

  public JTextField field = new JTextField();
  public JLabel text = new JLabel("Enter your name:");
  public JButton button = new JButton("Start Game");

  // This function sets the JPanel
  public PlayerPanel(Application a){
    super(a, 3, 1);

    text.setForeground(Color.WHITE);
    button.addActionListener(new ButtonListener());

    c.add(text);
    c.add(field);
    c.add(button);
  }

  // this is the custom ActionListener for this class
  class ButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      app.game.player.name = field.getText();
      app.showGame();
    }
  } 
}

