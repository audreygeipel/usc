package cosmoshunter.panels;

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

public class ScoresPanel extends AbstractPanel {

  public JLabel text = new JLabel("High Scores", JLabel.CENTER);
  public JButton button = new JButton("back");
  public Container table = new Container();

  // This function sets objects and adds them to Container
  // Also creates table and adds highscores
  public ScoresPanel(Application a){
    super(a, 3, 1);

    text.setForeground(Color.WHITE);
    button.addActionListener(new ButtonListener());
    int h = (app.game.scores.size() >= 10) ? 10 : app.game.scores.size();
    table.setLayout(new GridLayout(h, 2));

    c.setLayout(new BorderLayout(10, 10));
    c.add(text, BorderLayout.NORTH);
    c.add(table, BorderLayout.CENTER);
    c.add(button, BorderLayout.SOUTH);

    int i=0;
    for(Map.Entry<Integer, String > score: app.game.scores.entrySet()){
      if (i >= 10) break; i++;
      table.add(new JLabel(i + ". " + score.getValue(), JLabel.LEFT));
      table.getComponent(table.getComponentCount()-1).setForeground(Color.WHITE);

      table.add(new JLabel(String.valueOf(score.getKey()), JLabel.RIGHT));
      table.getComponent(table.getComponentCount()-1).setForeground(Color.WHITE);
    } 
  }

  // This function shows notification if there is no highscore
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    if (app.game.scores.size() == 0) {
      text.setText("No scores yet");
    } else {
      text.setText("High Scores");
    }
  }

  class ButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      app.showMenu();
    }
  } 
}

