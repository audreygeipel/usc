package cosmoshunter.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import cosmoshunter.*;

public class WorldInfoPanel extends AbstractPanel {

  public JPanel buttonBox = new JPanel();
  public JButton startGameB = new JButton("Continue Game");
  public ButtonListener listener = new ButtonListener();
  public JLabel text = new JLabel("Level completed!", JLabel.CENTER);
  public JLabel notif = new JLabel("Level Info", JLabel.CENTER);

  // This function sets objects and adds them to the Container
  public WorldInfoPanel(Application a){
    super(a, 3, 1);

    startGameB.addActionListener(listener);
    notif.setForeground(Color.WHITE);
    text.setForeground(Color.WHITE);
    buttonBox.setOpaque(false);

    buttonBox.add(startGameB);
    c.add(text);
    c.add(notif);
    c.add(buttonBox);
  }

  // This funcion updates the textfield for each galaxy
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    notif.setText(app.game.galaxy.info);
  }

  class ButtonListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      app.showGame();
    }
  }
}
