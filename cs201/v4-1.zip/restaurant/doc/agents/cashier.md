Cashier Agent Design Doc
=========================

Messages
--------

### msgHereIsBill(Bill bill)

    bills.put(bill, BillStatus.PENDING)

### msgHereIsMyPayment(Bill bill, int payment)

    bill.payedPrice = payment
    bills.put(bill, BillStatus.WAITING_CHANGE)

Rules
-----

### Rule #1

    if ∃ b in bills ∋ b.getValue() == BillStatus.WAITING_RECEIPT
      giveReceipt(b.getKey())

Actions
-------

### giveReceipt(Bill bill)

    bill.customer.msgHereIsYourReceipt()
    bills.put(bill, BillStatus.DONE)
    cash += bill.payedPrice

Data
----

### Variables

    Map<Bill, BillStatus> bills

    int cash

### Enums

    enum BillStatus {
      PENDING, WAITING_RECEIPT,
      DONE
    }
