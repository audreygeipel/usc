Customer Agent Design Doc
=========================

Messages
--------

### setHungry()

    events.add(AgentEvent.gotHungry)
    isHungry = true

### msgRestaurantIsFull()

    events.add(AgentEvent.restaurantFull)

### msgFollowMeToTable(WaiterAgent waiter, Menu menu)

    this.menu = menu
    this.waiter = waiter
    events.add(AgentEvent.beingSeated)

### msgDecided()

    events.add(AgentEvent.decidedChoice)

### msgWhatWouldYouLike()

    events.add(AgentEvent.waiterToTakeOrder)

### msgHereIsYourOrderAndBill(Order order, Bill bill)

    this.order = order
    this.bill = bill
    events.add(AgentEvent.foodDelivered)

### msgYourChoiceIsNotAvailble(Menu menu)

    this.menu = menu
    events.add(AgentEvent.choiceNotAvailable)

### msgDoneEating()

    events.add(AgentEvent.doneEating)

### msgHereIsYourReceipt()

    events.add(AgentEvent.madePayment)

Rules
-----

### Rule #0

    if events.isEmpty() 
      return false
    AgentEvent event = events.remove(0)

### Rule #1

    if state == AgentState.DoingNothing
      && event == AgentEvent.gotHungry
        goingToRestaurant()
        state = AgentState.WaitingInRestaurant

### Rule #2

    if state == AgentState.WaitingInRestaurant
      && event == AgentEvent.beingSeated
        makeMenuChoice()
        state = AgentState.SeatedWithMenu

### Rule #3

    if state = AgentState.WaitingInRestaurant
      && event = AgentEvent.restaurantFull
        leaveWithoutEating()
        state = AgentState.DoingNothing

### Rule #4

    if state == AgentState.SeatedWithMenu 
      && event == AgentEvent.decidedChoice 
        callWaiter()
        state = AgentState.WaiterCalled

### Rule #5

    if state == AgentState.WaiterCalled
      && event == AgentEvent.waiterToTakeOrder
        orderFood()
        state = AgentState.WaitingForFood

### Rule #6

    if state == AgentState.WaitingForFood
      && event == AgentEvent.foodDelivered
        eatFood()
        state = AgentState.Eating

### Rule #7

    if state == AgentState.WaitingForFood
      && event == AgentEvent.choiceNotAvailable
        makeMenuChoice()
        state = AgentState.SeatedWithMenu

### Rule #8

    if state == AgentState.Eating
      && event == AgentEvent.doneEating
        makePayment()
        state = AgentState.MakingPayment

### Rule #9

    if state == AgentState.MakingPayment
      && event == AgentEvent.madePayment
        leaveRestaurant()
        state = AgentState.DoingNothing

Actions
-------

### goingToRestaurant() 

    host.msgIWantToEat(this)

### leaveWithoutEating()

    host.msgImLeavingWithoutEating(this)

### makeMenuChoice()

    timer.schedule(new TimerTask() {
      public void run() {  
        msgDecided()
      }
    }, 3000)

### callWaiter()

    waiter.msgImReadyToOrder(this);

### orderFood()

    String choice = menu.choices[(int)(Math.random()*4)]
    waiter.msgHereIsMyChoice(this, choice)

### eatFood()

    Timer.schedule(new TimerTask() {
      public void run() {
        msgDoneEating()
      }
    }, getHungerLevel() * 1000)

### makePayment()

    Timer.schedule(new TimerTask() {
      public void run() {
        cashier.msgHereIsMyPayment(bill, bill.price)
      }
    }, getHungerLevel() * 1000)

### leaveRestaurant()

    waiter.msgDoneEatingAndLeaving(this)
    isHungry = false
    if (gui==null) becomeHungryInAWhile()

### becomeHungryInAWhile()

    timer.schedule(new TimerTask() {
      public void run() {  
        setHungry()
      }
    }, 15000)

Data
----

### Variables

    String name

    int hungerLevel = 5

    HostAgent host

    WaiterAgent waiter

    CashierAgent cashier

    Restaurant restaurant

    Menu menu

    Timer timer = new Timer()

    boolean isHungry = false

    int tableNum = NULL

    Order order

    Bill bill

    AgentState state = AgentState.DoingNothing

    List<AgentEvent> events = new ArrayList<AgentEvent>()

### Enums

    enum AgentState { 
      DoingNothing, WaitingInRestaurant, SeatedWithMenu, 
      WaiterCalled, WaitingForFood, Eating,
      MakingPayment
    }

    enum AgentEvent {
      gotHungry, beingSeated, decidedChoice, 
      waiterToTakeOrder, foodDelivered, doneEating,
      madePayment, choiceNotAvailable,
      restaurantFull
    }

