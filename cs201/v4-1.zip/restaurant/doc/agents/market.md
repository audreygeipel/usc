Market Agent Design Doc
=======================

Messages
--------

### msgHereIsMyOrder(MarketOrder marketOrder)

    marketOrders.put(marketOrder, MarketOrderStatus.PENDING)

Rules
-----

### Rule #1

    if ∃ mOrder in marketOrders ∋ mOrder.getValue() == MarketOrderStatus.PENDING
      processOrder(mOrder.getKey())

Actions
-------

### processOrder(MarketOrder marketOrder)

    if checkAvailability(marketOrder)
      deliverMarketOrder(marketOrder)
    else
      tellCookThatOrderIsNotAvailable(marketOrder)

### deliverMarketOrder(MarketOrder marketOrder)

    cook.msgHereIsYourOrderAndBill(marketOrder, new MarketBill(marketOrder))
    marketOrders.put(marketOrder, MarketOrderStatus.FULLFILLED)
    doDeliverMarketOrder(marketOrder)

### tellCookThatOrderIsNotAvailable(MarketOrder marketOrder)

    cook.msgYourOrderIsNotAvailable(MarketOrder)

Data
----

### Variables
 
    Map<MarketOrder, MarketOrderStatus> marketOrders

    Map<String, int> inventory

    CookAgent cook

### Enums

    enum MarketOrderStatus {
      PENDING, FULLFILLED
    }
