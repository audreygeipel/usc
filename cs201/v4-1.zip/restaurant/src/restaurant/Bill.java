package restaurant;

import restaurant.layoutGUI.*;
import restaurant.agent.*;

public class Bill {

  public CustomerAgent customer;
  public int price;
  public int payedPrice;

  /** Constructor for Order class */
  public Bill(CustomerAgent customer, int price){
    this.customer = customer;
    this.price = price;
  }
}

