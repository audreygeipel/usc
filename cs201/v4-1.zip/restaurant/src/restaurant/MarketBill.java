package restaurant;

import restaurant.layoutGUI.*;
import restaurant.agent.*;

public class MarketBill {

  public int price = 0;

  public MarketBill(MarketOrder mo){
    this.price = mo.quantity*10;
  }
}

