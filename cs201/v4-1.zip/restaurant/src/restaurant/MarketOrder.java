package restaurant;

import restaurant.layoutGUI.*;
import restaurant.agent.*;

public class MarketOrder {

  public String choice;
  public int quantity = 0;

  public MarketAgent market;

  public MarketOrder(String choice, int quantity, MarketAgent market){
    this.choice = choice;
    this.market = market;
    this.quantity = quantity;
  }
}

