package restaurant;

import java.util.*;

public class Menu {

  private HashMap<String, Integer> choices = new HashMap<String, Integer>();
  
  public Menu(){
    choices.put("Steak", 10);
    choices.put("Chicken", 7);
    choices.put("Pizza", 5);
    choices.put("Salad", 3);
  }

  public void removeChoice(String choice){
    choices.remove(choice);
  }

  public String getRandomChoice(){
    // TODO This is not so random
    int randomI = (int) Math.random()*4;
    int i = 0;
    for(String c:choices.keySet()){
      if (randomI == i){
        return c; 
      } else {
        i++; 
      }
    }
    return "";
  }

  public int getPrice(String choice){
    return choices.get(choice);
  }
}

