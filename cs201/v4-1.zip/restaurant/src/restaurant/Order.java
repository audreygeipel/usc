package restaurant;

import restaurant.layoutGUI.*;
import restaurant.agent.*;

/** Private class to store order information.
 *  Contains the waiter, table number, food item,
 *  cooktime and status.
 */
public class Order {

  public WaiterAgent waiter;
  public CustomerAgent customer;
  public int tableNum;
  public String choice;
  public FoodGui food; //a gui variable

  /** Constructor for Order class 
   * @param waiter waiter that this order belongs to
   * @param tableNum identification number for the table
   * @param choice type of food to be cooked 
   */
  public Order(WaiterAgent waiter, CustomerAgent customer, String choice){
    this.waiter = waiter;
    this.customer = customer;
    this.choice = choice;
    this.tableNum = customer.tableNum;
  }

  /** Represents the object as a string */
  public String toString(){
    return choice + " for " + waiter ;
  }
}

