package restaurant;

/** Private class storing all the information for each table,
 * including table number and state. */
public class Table {
  public int tableNum;
  public boolean occupied;

  /** Constructor for table class.
   * @param num identification number
   */
  public Table(int num){
    tableNum = num;
    occupied = false;
  } 
}

