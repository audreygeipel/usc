package restaurant.agent;

import java.util.*;

import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.layoutGUI.*;

/** Host agent for restaurant.
 *  Keeps a list of all the waiters and tables.
 *  Assigns new customers to waiters for seating and 
 *  keeps a list of waiting customers.
 *  Interacts with customers and waiters.
 */
public class HostAgent extends Agent {

  private enum CustomerStatus {
    WAITING_TABLE
  };

  // List of all the customers that are waiting 
  private Map<CustomerAgent, CustomerStatus> customers =
    Collections.synchronizedMap(new HashMap<CustomerAgent, CustomerStatus>());

  private enum WaiterStatus {
    WORKING, ON_BREAK
  };

  // List of all waiter that exist.
  private Map<WaiterAgent, WaiterStatus> waiters =
    Collections.synchronizedMap(new HashMap<WaiterAgent, WaiterStatus>());

  private enum WaiterEvent {
    NEEDS_BREAK
  };

  private Map<WaiterAgent, WaiterEvent> waiterEvents =
    Collections.synchronizedMap(new HashMap<WaiterAgent, WaiterEvent>());

  // Last waiter who seated customers
  private WaiterAgent lastWaiter = null;
  private int nextWaiter = 0;

  //List of all the tables
  int nTables;
  private Table tables[];

  //Name of the host
  private String name;

  /** Constructor for HostAgent class 
   * @param name name of the host */
  public HostAgent(String name, int ntables) {
    super();
    this.nTables = ntables;
    tables = new Table[nTables];

    for(int i=0; i < nTables; i++){
      tables[i] = new Table(i);
    }
    this.name = name;
  }

  // *** MESSAGES ***

  /** Customer sends this message to be added to the wait list 
   * @param customer customer that wants to be added */
  public void msgIWantToEat(CustomerAgent customer){
    customers.put(customer, CustomerStatus.WAITING_TABLE);
    stateChanged();
  }

  public void msgImLeavingWithoutEating(CustomerAgent customer){
    customers.remove(customer);
  }

  /** Waiter sends this message after the customer has left the table 
   * @param tableNum table identification number */
  public void msgTableIsFree(int tableNum){
    tables[tableNum].occupied = false;
    stateChanged();
  }

  public void msgINeedBreak(WaiterAgent waiter){
    waiterEvents.put(waiter, WaiterEvent.NEEDS_BREAK);
    stateChanged();
  }

  public void msgImBackToWorking(WaiterAgent waiter){
    waiters.put(waiter, WaiterStatus.WORKING);
    stateChanged();
  }

  /** Scheduler.  Determine what action is called for, and do it. */
  protected boolean pickAndExecuteAnAction() {

    int j = 0;
    for(WaiterAgent w:waiters.keySet()){
      if (waiters.get(w) == WaiterStatus.WORKING){

        // Find the next waiter
        print(String.valueOf(nextWaiter%getNumOfWaiters(WaiterStatus.WORKING)));
        j++;
        if (nextWaiter%getNumOfWaiters(WaiterStatus.WORKING) != j-1) {
          continue;
        }

        for(int i=0; i < nTables; i++){
          if(!tables[i].occupied){
            for(CustomerAgent c:customers.keySet()){
              if (customers.get(c) == CustomerStatus.WAITING_TABLE){
                tellWaiterToSitCustomerAtTable(w, c, i);
                nextWaiter++;
                return true;
              }
            }
          }
        }
      }
    }

    // Rule #2
    for(WaiterAgent w:waiterEvents.keySet()){
      if (waiterEvents.get(w) == WaiterEvent.NEEDS_BREAK
          && getNumOfWaiters(WaiterStatus.WORKING) >= 2){
        tellWaiterToGoOnBreak(w);
        return true;
      }
    }

    // Rule #3
    if (isRestaurantFull() && customers.size() > 1){
      tellCustomerThatRestaurantIsFull();
    }

    //we have tried all our rules (in this case only one) and found
    //nothing to do. So return false to main loop of abstract agent
    //and wait.
    return false;
  }

  // *** ACTIONS ***

  /** Assigns a customer to a specified waiter and 
   * tells that waiter which table to sit them at.
   * @param waiter
   * @param customer
   * @param tableNum */
  private void tellWaiterToSitCustomerAtTable(WaiterAgent waiter, CustomerAgent customer, int tableNum){
    print("Telling " + waiter + " to sit " + customer +" at table "+(tableNum+1));
    waiter.msgSitCustomerAtTable(customer, tableNum);
    tables[tableNum].occupied = true;
    customers.remove(customer);
    stateChanged();
  }

  private void tellWaiterToGoOnBreak(WaiterAgent waiter){
    print("Telling " + waiter + " to go on break");
    waiterEvents.remove(waiter);
    waiters.put(waiter, WaiterStatus.ON_BREAK);
    waiter.msgGoOnBreak();
    stateChanged();
  }

  private void tellCustomerThatRestaurantIsFull(){
    int size = customers.size();
    int i = 0;
    CustomerAgent customer;

    for(CustomerAgent c:customers.keySet()){
      i++;
      if (i == size){
        customer = c;
        print("Telling customer " + customer + " that restaurant is full");
        customer.msgRestaurantIsFull();
        customers.remove(customer);
      }
    }
  }

  // *** EXTRA ***

  /** Returns the name of the host 
   * @return name of host */
  public String getName(){
    return name;
  }    

  public int getNumOfWaiters(WaiterStatus ws){
    int count = 0;
    for(WaiterAgent w:waiters.keySet()){
      if (waiters.get(w) == ws){
        count++;
      }
    }
    return count;
  }

  public boolean isRestaurantFull(){
    for(int i=0; i < nTables; i++){
      if(!tables[i].occupied){
        return false;
      }
    }
    return true;
  }

  /** Hack to enable the host to know of all possible waiters 
   * @param waiter new waiter to be added to list
   */
  public void setWaiter(WaiterAgent waiter){
    waiters.put(waiter, WaiterStatus.WORKING);
    stateChanged();
  }

  //Gautam Nayak - Gui calls this when table is created in animation
  public void addTable() {
    nTables++;
    Table[] tempTables = new Table[nTables];
    for(int i=0; i < nTables - 1; i++){
      tempTables[i] = tables[i];
    }             
    tempTables[nTables - 1] = new Table(nTables - 1);
    tables = tempTables;
  }
}

