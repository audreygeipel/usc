package restaurant.agent;

import java.util.*;

import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.layoutGUI.*;

public class MarketAgent extends Agent {

  //Name of the cashier
  private String name;

  Timer timer = new Timer();

  private CookAgent cook;

  public enum MarketOrderStatus {
    PENDING, FULLFILLED
  };

  public HashMap<MarketOrder, MarketOrderStatus> marketOrders 
    = new HashMap<MarketOrder, MarketOrderStatus>();

  public MarketAgent(String name) {
    super();

    this.name = name;
  } 

  // *** MESSAGES ***
  
  public void msgHereIsMyOrder(CookAgent cook, MarketOrder mo){
    this.cook = cook;
    marketOrders.put(mo, MarketOrderStatus.PENDING);
    stateChanged();
  }

  /** Scheduler.  Determine what action is called for, and do it. */
  protected boolean pickAndExecuteAnAction() {
    
    // Rule #1
    for(MarketOrder mo:marketOrders.keySet()){
      if (marketOrders.get(mo) == MarketOrderStatus.PENDING){
        processOrder(mo);
        return true;
      }
    }

    return false;
  }

  // *** ACTIONS ***
  
  public void processOrder(MarketOrder mo){
    print("Processing Order");

    if (true){
      deliverMarketOrder(mo);
    } else {
      tellCookThatOrderIsNotAvailable(mo);
    }
  } 

  public void deliverMarketOrder(final MarketOrder mo){
    print("Delivering order cook (20sec)");
    marketOrders.put(mo, MarketOrderStatus.FULLFILLED);
    timer.schedule(new TimerTask() {
      public void run() {
        finishMarketOrder(mo);
      }
    }, 20000);
  }
  public void finishMarketOrder(MarketOrder mo){
    print("Order and bill are sent to cook");
    cook.msgHereIsYourOrderAndBill(mo, new MarketBill(mo));
  }

  public void tellCookThatOrderIsNotAvailable(MarketOrder mo){
    print("Order is not available");
    marketOrders.remove(mo);
  }

  // *** EXTRA ***

  /** Returns the name of the host 
   * @return name of cashier */
  public String getName(){
    return name;
  }    
}

