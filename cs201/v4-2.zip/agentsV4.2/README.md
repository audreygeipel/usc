Restaurant Simulation
=====================

Project Info
------------
+ Author   : Oguz Bilgic
+ Date	   : january-2012
+ Project  : CS 201 - Restaurant simulation with agents
+ Language : Java 

Project Overview
----------------

This is CSCI-201 (Fall 2011) - Agents project.  Purpose of this project is
designing a multi-threaded software.  Professor gave us the initial version
of the app (v3.1).

Compile
-------

Project uses `ant` tool for compile automation. Run this command to compile
the source code:

    ant compile

This will create `class` folder inside the `build` folder with compiled
source code.

Run
---

You can run the application with gui interface by using this command:

    ant restaurant

You can also run the application with out gui by using this command:

    ant run

Test
----

Project uses juint as a testing framework. You can run test by this command:

    ant test

This will first comile the source then runt the tests. Also this ill create
`test` folder inside the `build` folder with test results in it.

Documentation
-------------

Documentation for this project is written by using markdown markup
language. But these files are in plain text format so any text editor can
open these files. All documents are stored under `docs` folder.
Documentation for agent classes are under `doc/agents` folder. Interaction
diagrams of Agents for each scenerio is under `doc/pdf` folder.

Javadoc
-------

Project uses `javadoc` tool and markup language to document source code.
You can generate javadocs by running this command:

    ant javadoc

This will create folder a called `javadoc` in `build` folder with generated
documentation

CHANGELOG
---------

### v4.2.0

+ Add OrderQueue class for ProducerConsumer model
+ Add AbstractWaiterAgent 
+ Add QueueWaiterAgent which extends AbstractWaiterAgent
+ WaiterAgent now extends AbstractWaiterAgent
+ CookAgent can get order via message or OrderQueue

### v4.1.3

+ Implement multi-step action for WaiterAgent's takeOrder action 

### v4.1.2

+ Thread-safe all Agents with Synchronized Collections 

### v4.1.1

+ Add MockAgents for Customer
+ Add CashierAgentTests class for unit testing

### v4.1.0

+ Scenerio diagrams of agents are added
+ Fixed bug for multiple waiter

### v3.5.0

+ HostAgent tell CustomerAgent that Restaurant is full if there are more
  than 2 waiting CustomerAgents
+ CustomerAgent can leave the restaurant 
+ CustomerAgent also disappears from gui !

### v3.4.0

+ Add MarketAgent to Restaurant
+ CookAgent keeps track of it's inventory
+ CookAgent orders food from MarketAgent if inventory is low
+ CookAgent asks WaiterAgent to get another order from CustomerAgent if
  food is not available
+ CustomerAgent gets a new menu if his order is not available and orders
  something else

### v3.3.0

+ WaiterAgent can ask HostAgent permit for going on break
+ HostAgent allows WaiterAgent to go on break if there are other WaiterAgent working 
+ WaiterAgent finishes his customers and goes on break

### v3.2.0

+ Add CashierAgent to Restaurant
+ CustomerAgent receives Bill with his order
+ CustomerAgent makes payment to CashierAgent before leaving Restaurant
+ Menu class now know prices of choices

### v3.1.6

+ WaiterAgent keeps track of orders with their statuses (uses HashMap)
+ CookAgent receives Order object from WaiterAgent instead of seperate data
+ CookAgent sends Order object to WaiterAgent instead of seperate data

### v3.1.5

+ Use HashMaps as Agents' que data type

### v3.1.4

+ Move internal classes of Agents to seperate files
+ Rename FoodData class to Food

### v3.1.3

+ Remove unused files
+ Create agents package for agent classes
+ Change/Fix names of gui package classes

### v3.1.2

+ Add documentation for v4.1 agents

### v3.1.1

+ Remove unused files
+ Add README
+ Fix Java codding conventions
+ Rewrite build.xml

### v3.1

+ Inital version provided by Prof. 

Citation
--------

+ v3.1 is given by Prof. David Wilczynski

