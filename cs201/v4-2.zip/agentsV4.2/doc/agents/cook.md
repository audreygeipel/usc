Cook Agent Design Doc
=====================

Messages
--------

### msgHereIsAnOrder(Order order)

    orders.put(order, OrderStatus.PENDING)

### msgHereIsYourOrderAndBill(MarketOrder marketOrder, MarketBill marketBill)

    marketOrders.put(marketOrder, MarketOrderStatus.FULLFILLED)
    marketBills.put(marketBill, MarketBillStatus.PENDING)

### msgYourOrderIsNotAvailable(MarketOrder marketOrder)

    marketOrders.put(marketOrder, MarketOrderStatus.NOT_AVAILABLE)

Rules
-----

### Rule #1

    if ∃ o in orders ∋ o.getValue() == OrderStatus.DONE
      placeOrder(o.getKey())

### Rule #2

    if ∃ o in orders ∋ o.getValue() == OrderStatus.PENDING
      cookOrder(o.getKey())

### Rule #3

    if ∃ o in orders ∋ o.getValue() == OrderStatus.NOT_AVAILABLE
      requestOrderChange(o.getKey())

### Rule #4 
 
    if ∃ mO in marketOrders ∋ mO.getValue() == MarketOrderStatus.PENDING
      sendOrderToMarket(mO.getKey())

### Rule #5 
   
    if ∃ mO in marketOrders ∋ mO.getValue() == MarketOrderStatus.NOT_AVAILABLE
      sendOrderToAnotherMarket(mO.getKey())

Actions
-------

### cookOrder(Order order)

    DoCooking(order)
    orders.put(order, OrderStatus.COOKING)

### placeOrder(Order order)

    DoPlacement(order)
    order.waiter.msgOrderIsReady(order)
    orders.remove(order)

### requestOrderChange(Order order)

    order.waiter.msgOrderIsNotAvailable(order)
    orders.remove(order)

### sendOrderToMarket(MarketOrder marketOrder)

    marketOrder.market.msgHereIsMyOrder(marketOrder)
    marketOrders.put(marketOrder, MarketOrderStatus.ORDERED)

### sendOrderToAnotherMarket(MarketOrder marketOrder)
    
    changeMarket(marketOrder)
    sendOrderToMarket(marketOrder)

Data
----

### Variables

    List<MarketAgents> markets

    Map<Order, OrderStatus> orders

    Map<MarketOrder, MarketOrderStatus> marketOrders

    Map<MarketBill, MarketBillStatus> marketBills

    Map<String, int> inventory

### Enums

    emum OrderStatus { 
      PENDING, NOT_AVAILABLE,
      COOKING, DONE
    }

    emum MarketBillStatus { 
      PENDING
    }

    emum MarketOrderStatus { 
      PENDING, ORDERED, NOT_AVAILABLE, FULLFILLED
    }

