Helper Classes
--------------

### Food 

    class Food {
      String type
      double cookTime
    
      FoodData(String type, double cookTime){
        this.type = type
        this.cookTime = cookTime
      }
    }

### Menu
    
    class Menu {
      Map<String, int> choices;
      Map<String, int> prices
    
      Menu(Order order){
        choices.remove(order.choice)
      }
    }

### Order
    
    class Order {
      WaiterAgent waiter
      CustomerAgent customer
    
      String choice
    
      Order(WaiterAgent waiter, CustomerAgent customer, String choice){
        this.waiter = waiter
        this.customer = customer
        this.choice = choice
      }
    
      int price(){
       
      }
    }

### Bill
    
    class Bill (
      CustomerAgent customer
      int price  
      int payedPrice = 0
    
      Bill(Order order){
        this.customer = order.customer
        this.price = order.price()
      }
    )

### MarketOrder
    
    class MarketOrder {
      String food
      int quantity = 0
      MarketAgent market
    
      MarketOrder(String f, int q, MarketAgent market){
        this.food = f
        this.quantity = q
        this.market = market
      }
    }

### MarketBill
    
    class MarketBill {
      int price = 0
    
      MarketBill(MarketOrder marketOrder){
        this.price = marketOrder.quantity * 10
      }
    }

### Table
    
    class Table {
      int tableNum
      boolean occupied
    
      Table(int num){
        tableNum = num
        occupied = false
      } 
    }
    
