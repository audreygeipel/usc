Host Agent Design Doc
=====================

Messages
--------

### msgIWantToEat(CustomerAgent customer)

    customers.put(customer, CustomerStatus.WAITING_TABLE)

### msgImLeavingWithoutEating(CustomerAgent customer)

    customers.remove(customer)

### msgTableIsFree(int tableNum)
 
    tables[tableNum].occupied = false

### msgINeedBreak(WaiterAgent waiter)

    waiterEvents.put(waiter, WaiterEvents.NEEDS_BREAK)

### msgImBackToWorking(WaiterAgent waiter)

    waiters.put(waiter, WaiterState.WORKING)

Rules
-----

### Rule #1

    if ∃ table in tables ∋ ~table.occupied
      && ∃ w in waiters ∋ w.getValue() == WaiterStatus.WORKING
      && ∃ c in customers ∋ c.getValue() == CustomerStatus.WAITING_TABLE
        tellWaiterToSitCustomerAtTable(w.getKey(), c.getKey(), table.tableNum)

### Rule #3

    if ∀ table in tables ∋ table.occupied
      && customers.size() > 2
        tellCustomerthatRestaurantIsFull(customers.last().getKey())

### Rule #2 

    if ∃ wE in waiterEvents ∋ wE.getValue() == WaiterEvent.NEEDS_BREAK 
      ∃ w in waiters ∋ w.getValue() == WaiterState.WORKING && w.getKey() != wE.getKey()
        tellWaiterToGoOnBreak(w.getKey())

Actions
-------

### tellWaiterToSitCustomerAtTable(WaiterAgent waiter, CustomerAgent customer, int tableNum)

    waiter.msgSitCustomerAtTable(customer, tableNum)
    tables[tableNum].occupied = true
    customers.remove(customer)

### tellWaiterToGoOnBreak(WaiterAgent waiter)

    waiterEvents.remove(waiter)
    waiters.put(waiter, WaiterState.ON_BREAK)
    waiter.msgGoOnBreak()

### tellCustomerthatRestaurantIsFull(CustomerAgent customer)

    customer.msgRestaurantIsFull()
    
Data
----

### Variables

    int nTables

    Table tables[]

    String name

    Map<CustomerAgent, CustomerStatus> customers

    Map<WaiterAgent, WaiterState> waiters

    Map<WaiterAgent, waiterEvents> waiterEvents

### Enums

    enum CustomerStatus {
      WAITING_TABLE
    }

    enum WaiterState {
      WORKING, ON_BREAK 
    }

    enum WaiterEvent {
      NEEDS_BREAK
    }
