Waiter Agent Design Doc
=======================

Messages
--------

### msgSitCustomerAtTable(CustomerAgent customer, int tableNum)

    customers.put(customer, CustomerStatus.NEED_SEATED)
    customer.tableNum = tableNum

### msgImReadyToOrder(CustomerAgent customer)

    customers.put(customer, CustomerStatus.READY_TO_ORDER)

### msgHereIsMyChoice(CustomerAgent customer, String choice)

    orders.put(new Order(this, customer, choice), OrderStatus.PENDING)
    customers.put(customer, CustomerStatus.NO_ACTION)
    
### msgDoneEatingAndLeaving(CustomerAgent customer)

    customers.put(customer, CustomerStatus.IS_DONE)

### msgOrderIsReady(Order order)

    orders.put(order, OrderStatus.READY)

### msgOrderIsNotAvailable(Order order)

    orders.put(order, OrderStatus.NOT_AVAILABLE)

### setBreakStatus(boolean state)

    if state == true
      status = WaiterStatus.NEEDS_BREAK

### msgGoOnBreak()

    status = WaiterStatus.FINISHING_CUSTOMERS

### msgFinishBreak()

    status = WaiterStatus.WORKING
 

Rules
-----

### Rule #1

    if ∃ c in customers ∋ c.getValue() == CustomerStatus.NEED_SEATED
      seatCustomer(c.getKey())

### Rule #2

    if ∃ c in customers ∋ c.getValue() == CustomerStatus.READY_TO_ORDER
      takeOrder(c.getKey())

### Rule #3

    if ∃ c in customers ∋ c.getValue() == CustomerStatus.IS_DONE
      clearTable(c.getKey())
    
### Rule #4

    if ∃ o in orders ∋ o.getValue() == OrderStatus.PENDING
      giveOrderToCook(o.getKey())

### Rule #5

    if ∃ o in orders ∋ o.getValue() == OrderStatus.READY
      giveOrderToCustomer(o.getKey())

### Rule #6

    if ∃ o in orders ∋ o.getValue() == OrderStatus.NOT_AVAILABLE
      giveNewMenuToCustomer(o.getKey())

### Rule #7

    if status == WaiterStatus.NEEDS_BREAK
      requestBreak()

### Rule #8

    if status == WaiterStatus.FINISHING_CUSTOMERS
      && ø customers
        goOnBreak()

Actions
-------

### seatCustomer(CustomerAgent customer)

    customers.put(customer, CustomerStatus.NO_ACTION)
    customer.msgFollowMeToTable(this, new Menu())

### TakeOrder(CustomerAgent customer)

    customers.put(customer, CustomerStatus.NO_ACTION)
    customer.msgWhatWouldYouLike()

### giveOrderToCook(Order order)

    customers.put(customer, CustomerStatus.NO_ACTION)
    orders.put(order, OrderStatus.COOKING)
    cook.msgHereIsAnOrder(order)

### giveOrderToCustomer(Order order)

    customers.put(order.customer, CustomerStatus.NO_ACTION)
    order.customer.msgHereIsYourOrderAndBill(order, new Bill(order))
    orders.remove(order)

### giveNewMenuToCustomer(Order order)

    order.customer.msgYourChoiceIsNotAvailble(new Menu(order))
    orders.remove(order)

### clearTable(CustomerAgent customer)

    customers.remove(customer)

### requestBreak()

    host.msgINeedBreak(this)
    status = WaiterStatus.REQUESTED_BREAK

### goOnBreak()

    status = WaiterStatus.ON_BREAK
    Timer.schedule(new TimerTask() {
      void run() {
        msgFinishBreak()
      }
    }, 3000)


Data
----

### Variables

    String name

    HostAgent host

    CookAgent cook

    WaiterStatus status

    Map<CustomerAgent, CustomerStatus> customers 

    Map<Order, OrderStatus> orders 

### Enums

    enum WaiterStatus {
      NEEDS_BREAK, REQUESTED_BREAK, 
      FINISHING_CUSTOMERS, ON_BREAK,
      WORKING
    }

    enum OrderStatus {
      PENDING, COOKING, NOT_AVAILABLE, READY
    }

    enum CustomerStatus {
      NEED_SEATED, READY_TO_ORDER,
      IS_DONE, NO_ACTION
    }

