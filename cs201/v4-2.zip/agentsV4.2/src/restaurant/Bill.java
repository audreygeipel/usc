package restaurant;

import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.layoutGUI.*;

public class Bill {

  public Customer customer;
  public int price;
  public int payedPrice;

  /** Constructor for Order class */
  public Bill(Customer customer, int price){
    this.customer = customer;
    this.price = price;
  }
}

