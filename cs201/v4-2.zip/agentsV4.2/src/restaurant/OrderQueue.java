package restaurant;

import java.util.*;
import java.awt.Color;

import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;

public class OrderQueue extends Object {

  private final int N = 5;
  private int count = 0;
  private Vector<Order> theData;

  synchronized public void insert(Order order) {
    while (count == N) {
      try{ 
        System.out.println("\tFull, waiting");
        wait(5000);                         // Full, wait to add
      } catch (InterruptedException ex) {};
    }

    insert_order(order);
    count++;
    if(count == 1) {
      System.out.println("\tNot Empty, notify");
      notify(); 
    }
  }

  synchronized public Order remove() {
    Order order;
    while(count == 0)
      try{ 
        System.out.println("\tEmpty, waiting");
        wait(5000);                         // Empty, wait to consume
      } catch (InterruptedException ex) {};

    order = remove_order();
    count--;
    if(count == N-1){ 
      System.out.println("\tNot full, notify");
      notify();
    }
    return order;
  }

  private void insert_order(Order order){
    theData.addElement(order);
  }

  private Order remove_order(){
    Order order = (Order) theData.firstElement();
    theData.removeElementAt(0);
    return order;
  }

  public OrderQueue(){
    theData = new Vector<Order>();
  }
}

