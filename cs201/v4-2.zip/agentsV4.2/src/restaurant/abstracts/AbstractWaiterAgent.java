package restaurant.abstracts;

import java.awt.Color;
import java.util.*;
import java.util.concurrent.*;

import astar.*;
import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.layoutGUI.*;
import restaurant.gui.RestaurantGui;

/** Restaurant Waiter Agent.
 * Sits customers at assigned tables and takes their orders.
 * Takes the orders to the cook and then returns them 
 * when the food is done.  Cleans up the tables after the customers leave.
 * Interacts with customers, host, and cook */
abstract public class AbstractWaiterAgent extends Agent implements Waiter {

  Timer timer = new Timer();

  //Name of waiter
  private String name;

  private Semaphore lock = new Semaphore(0, true);

  private Agent locked_for_agent;

  private Object locked_for_object;

  enum WaiterStatus {
    NEEDS_BREAK, REQUESTED_BREAK, 
    FINISHING_CUSTOMERS, ON_BREAK,
    WORKING
  }

  private WaiterStatus status = WaiterStatus.WORKING;

  //State constants for Customers
  private enum CustomerStatus {
    NEED_SEATED, READY_TO_ORDER, 
    IS_DONE, NO_ACTION
  };

  //All the customers that this waiter is serving
  private Map<Customer, CustomerStatus> customers = 
    Collections.synchronizedMap(new HashMap<Customer, CustomerStatus>());

  private enum OrderStatus {
    PENDING, COOKING, NOT_AVAILABLE, 
    READY, NO_ACTION
  }

  private Map<Order, OrderStatus> orders = 
    Collections.synchronizedMap(new HashMap<Order, OrderStatus>());

  protected HostAgent host;
  protected CookAgent cook;
  protected CashierAgent cashier;

  //Animation Variables
  AStarTraversal aStar;
  Restaurant restaurant; //the gui layout
  WaiterGui guiWaiter; 
  Position currentPosition; 
  Position originalPosition;
  TableGui[] tables; //the gui tables

  /** Constructor for WaiterAgent class
   * @param name name of waiter
   * @param gui reference to the gui */
  public AbstractWaiterAgent(String name, AStarTraversal aStar,
      Restaurant restaurant, TableGui[] tables) {
    super();

    this.name = name;

    //initialize all the animation objects
    this.aStar = aStar;
    this.restaurant = restaurant;//the layout for astar
    guiWaiter = new WaiterGui(name.substring(0,2), new Color(255, 0, 0), restaurant);
    currentPosition = new Position(guiWaiter.getX(), guiWaiter.getY());
    currentPosition.moveInto(aStar.getGrid());
    originalPosition = currentPosition;//save this for moving into
    this.tables = tables;
  } 

  // *** MESSAGES ***

  /** Host sends this to give the waiter a new customer.
   * @param customer customer who needs seated.
   * @param tableNum identification number for table */
  public void msgSitCustomerAtTable(Customer customer, int tableNum){
    customer.setTableNum(tableNum);
    customers.put(customer, CustomerStatus.NEED_SEATED);
    stateChanged();
  }

  /** Customer sends this when they are ready.
   * @param customer customer who is ready to order.
   */
  public void msgImReadyToOrder(Customer customer){
    customers.put(customer, CustomerStatus.READY_TO_ORDER);
    stateChanged();
  }

  /** Customer sends this when they have decided what they want to eat 
   * @param customer customer who has decided their choice
   * @param choice the food item that the customer chose */
  public void msgHereIsMyChoice(Customer customer, String choice){
    Order order = new Order(this, customer, choice);

    locked_for_object = order;
    locked_for_agent = (Agent) customer;

    lock.release();
    stateChanged();
  }

  /** Customer sends this when they are done eating.
   * @param customer customer who is leaving the restaurant. */
  public void msgDoneEatingAndLeaving(Customer customer){
    customers.put(customer, CustomerStatus.IS_DONE);
    stateChanged();
  }

  /** Cook sends this when the order is ready.
   * @param tableNum identification number of table whose food is ready
   * @param f is the guiFood object */
  public void msgOrderIsReady(Order order){
    orders.put(order, OrderStatus.READY);
    stateChanged();
  }

  public void msgOrderIsNotAvailable(Order order){
    orders.put(order, OrderStatus.NOT_AVAILABLE);
    stateChanged();
  }

  /** Sent from GUI to control breaks 
   * @param state true when the waiter should go on break and 
   *              false when the waiter should go off break
   *              Is the name onBreak right? What should it be?*/
  public void setBreakStatus(boolean state){
    if (state == true)
      status = WaiterStatus.NEEDS_BREAK;
    stateChanged();
  }

  public void msgGoOnBreak(){
    status = WaiterStatus.FINISHING_CUSTOMERS;
    stateChanged();
  }

  /** Scheduler.  Determine what action is called for, and do it. */
  protected boolean pickAndExecuteAnAction() {

    synchronized(customers){
      // Rule #1
      //Seats the customer if they need it
      for(Customer c:customers.keySet()){
        if (customers.get(c) == CustomerStatus.NEED_SEATED){
          seatCustomer(c);
          return true;
        }
      }

      // Rule #2
      //Takes new orders for customers that are ready
      for(Customer c:customers.keySet()){
        if (customers.get(c) == CustomerStatus.READY_TO_ORDER){
          takeOrder(c);
          return true;
        }
      }	    

      // Rule #3
      //Clears the table if the customer has left
      for(Customer c:customers.keySet()){
        if (customers.get(c) == CustomerStatus.IS_DONE){
          clearTable(c);
          return true;
        }
      }
    }

    synchronized(orders){
      // Rule #4
      //for(Order o:orders.keySet()){
      //  if (orders.get(o) == OrderStatus.PENDING){
    //    giveOrderToCook(o);
    //    return true;
      //  }
      //}

      // Rule #5
      for(Order o:orders.keySet()){
        if (orders.get(o) == OrderStatus.READY){
          giveOrderToCustomer(o);
          return true;
        }
      }

      // Rule #6
      for(Order o:orders.keySet()){
        if (orders.get(o) == OrderStatus.NOT_AVAILABLE){
          giveNewMenuToCustomer(o);
          return true;
        }
      }
    }

    // Rule #7
    if (status == WaiterStatus.NEEDS_BREAK){
      requestBreak();
      return true;
    }

    // Rule #8
    if (status == WaiterStatus.FINISHING_CUSTOMERS
        && customers.isEmpty()){
      goOnBreak();
      return true;
        }

    if (!currentPosition.equals(originalPosition)) {
      DoMoveToOriginalPosition();//Animation thing
      return true;
    }

    //we have tried all our rules and found nothing to do. 
    // So return false to main loop of abstract agent and wait.
    //print("in scheduler, no rules matched:");
    return false;
  }

  // *** ACTIONS ***

  /** Seats the customer at a specific table 
   * @param customer customer that needs seated */
  private void seatCustomer(Customer customer) {
    DoSeatCustomer(customer); //animation	
    customers.put(customer, CustomerStatus.NO_ACTION);
    customer.msgFollowMeToTable(this, new Menu());
    stateChanged();
  }

  /** Takes down the customers order 
   * @param customer customer that is ready to order */
  private void takeOrder(Customer customer) {
    DoTakeOrder(customer); //animation
    customers.put(customer, CustomerStatus.NO_ACTION);
    customer.msgWhatWouldYouLike();
    try {
      while(true){
        lock.acquire();
        customers.put((Customer) locked_for_agent, CustomerStatus.NO_ACTION);
        orders.put((Order) locked_for_object, OrderStatus.PENDING);
        if (locked_for_agent == customer){
          break;
        }
      }
    } catch (Exception e) {
      print("Unexpected exception caught in Agent thread:", e);
    }
    giveOrderToCook((Order) locked_for_object);
  }

  /** Gives any pending orders to the cook 
   * @param customer customer that needs food cooked */
  private void giveOrderToCook(Order order) {
    print("Giving " + order.customer + "'s choice of " + order.choice + " to cook");

    customers.put(order.customer, CustomerStatus.NO_ACTION);
    orders.put(order, OrderStatus.COOKING);
    sendOrderToCook(order);
    stateChanged();

    //Here's a little animation hack. We put the first two
    //character of the food name affixed with a ? on the table.
    //Simply let's us see what was ordered.
    tables[order.tableNum].takeOrder(order.choice.substring(0,2)+"?");
    restaurant.placeFood(tables[order.tableNum].foodX(),
        tables[order.tableNum].foodY(),
        new Color(255, 255, 255), order.choice.substring(0,2)+"?");
  }

  abstract public void sendOrderToCook(Order order);

  /** Gives food to the customer 
   * @param customer customer whose food is ready */
  private void giveOrderToCustomer(Order order) {
    DoGiveOrderToCustomer(order);//Animation
    customers.put(order.customer, CustomerStatus.NO_ACTION);
    orders.put(order, OrderStatus.NO_ACTION);
    Menu menu = new Menu();
    Bill bill = new Bill(order.customer, menu.getPrice(order.choice));
    order.customer.msgHereIsYourFoodAndBill(order.choice, bill, cashier);
    cashier.msgHereIsBill(bill);
    stateChanged();
  }

  private void giveNewMenuToCustomer(Order order){
    print("Giving new menu to customer" + order.customer);
    Menu menu = new Menu();
    menu.removeChoice(order.choice);
    order.customer.msgYourChoiceIsNotAvailable(menu);
    orders.remove(order);
    customers.put(order.customer, CustomerStatus.NO_ACTION);
    stateChanged();
  }

  /** Starts a timer to clear the table 
   * @param customer customer whose table needs cleared */
  private void clearTable(Customer customer) {
    DoClearingTable(customer);
    customers.put(customer, CustomerStatus.NO_ACTION);
    stateChanged();
  }

  private void requestBreak(){
    print("I need break");
    host.msgINeedBreak(this);
    status = WaiterStatus.REQUESTED_BREAK;
    stateChanged();
  }

  public void goOnBreak(){
    status = WaiterStatus.ON_BREAK;
    print("Going on break (15000)");
    timer.schedule(new TimerTask(){
      public void run(){		    
        finishBreak();
      }
    }, 15000);
    stateChanged();
  }

  public void finishBreak(){
    print("Came back from break");
    status = WaiterStatus.WORKING;
    host.msgImBackToWorking(this);
    stateChanged();
  }

  // Animation Actions
  void DoSeatCustomer (Customer customer){
    print("Seating " + customer + " at table " + (customer.getTableNum()+1));
    //move to customer first.
    CustomerGui guiCustomer = customer.getGuiCustomer();
    guiMoveFromCurrentPostionTo(new Position(guiCustomer.getX()+1,guiCustomer.getY()));
    guiWaiter.pickUpCustomer(guiCustomer);
    Position tablePos = new Position(tables[customer.getTableNum()].getX()-1,
        tables[customer.getTableNum()].getY()+1);
    guiMoveFromCurrentPostionTo(tablePos);
    guiWaiter.seatCustomer(tables[customer.getTableNum()]);
  }

  void DoTakeOrder(Customer customer){
    print("Taking " + customer +"'s order.");
    Position tablePos = new Position(tables[customer.getTableNum()].getX()-1,
        tables[customer.getTableNum()].getY()+1);
    guiMoveFromCurrentPostionTo(tablePos);
  }

  void DoGiveOrderToCustomer(Order order){
    print("Giving finished order of " + order.choice +" to " + order.customer);
    Position inFrontOfGrill = new Position(order.food.getX()-1, order.food.getY());
    guiMoveFromCurrentPostionTo(inFrontOfGrill);//in front of grill
    guiWaiter.pickUpFood(order.food);
    Position tablePos = new Position(tables[order.tableNum].getX()-1,
        tables[order.tableNum].getY()+1);
    guiMoveFromCurrentPostionTo(tablePos);
    guiWaiter.serveFood(tables[order.tableNum]);
  }

  void DoClearingTable(final Customer customer){
    print("Clearing table " + (customer.getTableNum()+1) + " (1500 milliseconds)");
    timer.schedule(new TimerTask(){
      public void run(){		    
        endCustomer(customer);
      }
    }, 1500);
  }

  /** Function called at the end of the clear table timer
   * to officially remove the customer from the waiter's list.
   * @param customer customer who needs removed from list */
  private void endCustomer(Customer customer){ 
    print("Table " + (customer.getTableNum()+1) + " is cleared!");
    for(Order o:orders.keySet()){
      if (o.customer == customer){
        o.food.remove();
        orders.remove(o);
      }
    }
    host.msgTableIsFree(customer.getTableNum());
    customers.remove(customer);
    stateChanged();
  }

  private void DoMoveToOriginalPosition(){
    print("Nothing to do. Moving to original position="+originalPosition);
    guiMoveFromCurrentPostionTo(originalPosition);
  }

  //this is just a subroutine for waiter moves. It's not an "Action"
  //itself, it is called by Actions.
  void guiMoveFromCurrentPostionTo(Position to){
    //System.out.println("[Gaut] " + guiWaiter.getName() + " moving from " + currentPosition.toString() + " to " + to.toString());

    AStarNode aStarNode = (AStarNode)aStar.generalSearch(currentPosition, to);
    List<Position> path = aStarNode.getPath();
    Boolean firstStep   = true;
    Boolean gotPermit   = true;

    for (Position tmpPath: path) {
      //The first node in the path is the current node. So skip it.
      if (firstStep) {
        firstStep   = false;
        continue;
      }

      //Try and get lock for the next step.
      int attempts    = 1;
      gotPermit       = new Position(tmpPath.getX(), tmpPath.getY()).moveInto(aStar.getGrid());

      //Did not get lock. Lets make n attempts.
      while (!gotPermit && attempts < 3) {
        //System.out.println("[Gaut] " + guiWaiter.getName() + " got NO permit for " + tmpPath.toString() + " on attempt " + attempts);

        //Wait for 1sec and try again to get lock.
        try { Thread.sleep(1000); }
        catch (Exception e){}

        gotPermit   = new Position(tmpPath.getX(), tmpPath.getY()).moveInto(aStar.getGrid());
        attempts ++;
      }

      //Did not get lock after trying n attempts. So recalculating path.            
      if (!gotPermit) {
        //System.out.println("[Gaut] " + guiWaiter.getName() + " No Luck even after " + attempts + " attempts! Lets recalculate");
        guiMoveFromCurrentPostionTo(to);
        break;
      }

      //Got the required lock. Lets move.
      //System.out.println("[Gaut] " + guiWaiter.getName() + " got permit for " + tmpPath.toString());
      currentPosition.release(aStar.getGrid());
      currentPosition = new Position(tmpPath.getX(), tmpPath.getY ());
      guiWaiter.move(currentPosition.getX(), currentPosition.getY());
    }
  }

  // *** EXTRA ***

  /** @return name of waiter */
  public String getName(){
    return name;
  }

  /** @return string representation of waiter */
  public String toString(){
    return "waiter " + getName();
  }

  /** Hack to set the cook for the waiter */
  public void setCook(CookAgent cook){
    this.cook = cook;
  }

  /** Hack to set the host for the waiter */
  public void setHost(HostAgent host){
    this.host = host;
  }

  /** Hack to set the host for the waiter */
  public void setCashier(CashierAgent cashier){
    this.cashier = cashier;
  }

  /** @return true if the waiter is on break, false otherwise */
  public boolean isOnBreak(){
    if(status == WaiterStatus.ON_BREAK){
      return true;
    } else {
      return false;
    }
  }
}

