package restaurant.agent;

import java.util.*;

import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.layoutGUI.*;

public class CashierAgent extends Agent implements Cashier {

  //Name of the cashier
  private String name;

  Timer timer = new Timer();

  public enum BillStatus{
    PENDING, WAITING_RECEIPT, DONE
  }

  public Map<Bill, BillStatus> bills = 
    Collections.synchronizedMap(new HashMap<Bill, BillStatus>());

  public CashierAgent(String name, Restaurant restaurant) {
    super();

    this.name = name;
  } 

  // *** MESSAGES ***
  
  public void msgHereIsBill(Bill bill){
    bills.put(bill, BillStatus.PENDING);
    stateChanged();
  }
  
  public void msgHereIsMyPayment(Bill bill, int price){
    bill.payedPrice = price;
    bills.put(bill, BillStatus.WAITING_RECEIPT);
    stateChanged();
  }

  /** Scheduler.  Determine what action is called for, and do it. */
  public boolean pickAndExecuteAnAction() {
    synchronized(bills){
      for(Bill b:bills.keySet()){
        if(bills.get(b) == BillStatus.WAITING_RECEIPT){
          giveReceipt(b);  
          return true;
        }
      }
    }

    return false;
  }

  // *** ACTIONS ***
  
  public void giveReceipt(final Bill bill){
    print("Payment Received:" + bill.payedPrice);
    print("Printing receipt (1500 ms)");
    bills.put(bill, BillStatus.DONE);
    timer.schedule(new TimerTask() {
      public void run() {  
        bill.customer.msgHereIsYourReceipt();
        print("Receipt sent to customer:" + bill.customer);
      }
    }, 1500);//how long to wait before running task
    stateChanged();
  }

  // *** EXTRA ***

  /** Returns the name of the host 
   * @return name of cashier */
  public String getName(){
    return name;
  }    
}

