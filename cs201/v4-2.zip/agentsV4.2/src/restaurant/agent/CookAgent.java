package restaurant.agent;

import java.util.*;
import java.awt.Color;

import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.layoutGUI.*;

/** Cook agent for restaurant.
 *  Keeps a list of orders for waiters
 *  and simulates cooking them.
 *  Interacts with waiters only.
 */
public class CookAgent extends Agent implements Cook {

  //Name of the cook
  private String name;

  private OrderQueue orderQueue;

  //Timer for simulation
  Timer timer = new Timer();
  Restaurant restaurant; //Gui layout

  private enum OrderStatus {
    PENDING, NOT_AVAILABLE,
    COOKING, DONE
  };

  //Map of all the orders with their statuses
  private Map<Order, OrderStatus> orders = 
    Collections.synchronizedMap(new HashMap<Order, OrderStatus>());

  private Map<String, Integer> cookTime = 
    Collections.synchronizedMap(new HashMap<String, Integer>());

  private Map<String, Integer> inventory = 
    Collections.synchronizedMap(new HashMap<String, Integer>());

  private enum MarketOrderStatus { 
    PENDING, ORDERED, NOT_AVAILABLE, FULLFILLED
  };

  private Map<MarketOrder, MarketOrderStatus> marketOrders = 
    Collections.synchronizedMap(new HashMap<MarketOrder, MarketOrderStatus>());

  private enum MarketBillStatus { 
    PENDING
  }

  private Map<MarketBill, MarketBillStatus> marketBills = 
    Collections.synchronizedMap(new HashMap<MarketBill, MarketBillStatus>());

  private MarketAgent market;

  /** Constructor for CookAgent class
   * @param name name of the cook
   */
  public CookAgent(String name, Restaurant restaurant) {
    super();

    this.name = name;
    this.restaurant = restaurant;

    cookTime.put("Steak", 5);
    cookTime.put("Chicken", 4);
    cookTime.put("Pizza", 3);
    cookTime.put("Salad", 2);

    inventory.put("Steak", 5);
    inventory.put("Chicken", 4);
    inventory.put("Pizza", 3);
    inventory.put("Salad", 1);
  }

  // *** MESSAGES ***

  /** Message from a waiter giving the cook a new order.
   * @param waiter waiter that the order belongs to
   * @param tableNum identification number for the table
   * @param choice type of food to be cooked
   */
  public void msgHereIsAnOrder(Order order){
    orders.put(order, OrderStatus.PENDING);
    stateChanged();
  }

  public void msgHereIsYourOrderAndBill(MarketOrder mo, MarketBill mb){
    marketOrders.put(mo, MarketOrderStatus.FULLFILLED);
    inventory.put(mo.choice, mo.quantity);
    marketBills.put(mb, MarketBillStatus.PENDING);
    stateChanged();
  }

  /** Scheduler.  Determine what action is called for, and do it. */
  protected boolean pickAndExecuteAnAction() {
   
    synchronized(orders){

      // Rule #1
      //If there exists an order o whose status is done, place o.
      for(Order o:orders.keySet()){
        if (orders.get(o) == OrderStatus.DONE){
          placeOrder(o);
          return true;
        }
      }

      // Rule #2
      for(Order o:orders.keySet()){
        if (orders.get(o) == OrderStatus.PENDING){
          cookOrder(o);
          return true;
        }
      }

      // Rule #3
      for(Order o:orders.keySet()){
        if (orders.get(o) == OrderStatus.NOT_AVAILABLE){
          requestOrderChange(o);
          return true;
        }
      }

    }

    synchronized(marketOrders){

      // Rule #4
      for(MarketOrder mo:marketOrders.keySet()){
        if (marketOrders.get(mo) == MarketOrderStatus.PENDING){
          sendOrderToMarket(mo);
          return true;
        }
      }

    }

    //we have tried all our rules (in this case only one) and found
    //nothing to do. So return false to main loop of abstract agent
    //and wait.
    return false;
  }

  // *** ACTIONS ***

  /** Starts a timer for the order that needs to be cooked. 
   * @param order
   */
  private void cookOrder(Order order){
    if(checkInventory(order.choice)){
      DoCooking(order);
      orders.put(order, OrderStatus.COOKING);
    } else {
      orders.put(order, OrderStatus.NOT_AVAILABLE);
    }
  }

  public void checkOrderQueue(){
    print("Checking Order Queue");
    timer.schedule(new TimerTask(){
      public void run(){    
        msgHereIsAnOrder(orderQueue.remove());
        checkOrderQueue();
      }
    }, 7000);

  }

  private boolean checkInventory(String choice){
    int count = inventory.get(choice); 

    if(count <= 2){
      marketOrders.put(new MarketOrder(choice, 5, market), MarketOrderStatus.PENDING);
      stateChanged();
    }

    if(count > 0){
      return true;
    } else {
      return false;
    }
  }

  private void requestOrderChange(Order o){
    print("Food " + o.choice + " is not available, requested order change");
    o.waiter.msgOrderIsNotAvailable(o);
    orders.remove(o);
  }

  private void placeOrder(Order order){
    DoPlacement(order);
    order.waiter.msgOrderIsReady(order);
    orders.remove(order);
  }

  private void sendOrderToMarket(MarketOrder mo){
    print("Ordered food:" + mo.choice + " from market:" + mo.market);
    mo.market.msgHereIsMyOrder(this, mo);
    marketOrders.put(mo, MarketOrderStatus.ORDERED);
  }

  // *** EXTRA -- all the simulation routines***

  /** Returns the name of the cook */
  public String getName(){
    return name;
  }

  public void setMarket(MarketAgent market){
    this.market = market;
  }

  public void setOrderQueue(OrderQueue orderQueue){
    this.orderQueue = orderQueue;
    checkOrderQueue();
  }

  private void DoCooking(final Order order){
    print("Cooking:" + order + " for table:" + (order.tableNum+1));

    inventory.put(order.choice, inventory.get(order.choice)-1);
    order.food = new FoodGui(order.choice.substring(0,2),new Color(0,255,255), restaurant);
    order.food.cookFood();

    timer.schedule(new TimerTask(){
      public void run(){//this routine is like a message reception    
        orders.put(order, OrderStatus.DONE);
        stateChanged();
      }
    }, (int)(cookTime.get(order.choice) * 1000));
  }

  public void DoPlacement(Order order){
    print("Order finished: " + order + " for table:" + (order.tableNum+1));
    order.food.placeOnCounter();
  }
}

