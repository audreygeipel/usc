package restaurant.agent;

import java.awt.Color;
import java.util.*;
import java.util.concurrent.*;

import astar.*;
import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.abstracts.*;
import restaurant.layoutGUI.*;
import restaurant.gui.RestaurantGui;

public class QueueWaiterAgent extends AbstractWaiterAgent {

  private OrderQueue orderQueue;

  public QueueWaiterAgent(String name, AStarTraversal aStar, Restaurant restaurant, TableGui[] tables) {
    super(name, aStar, restaurant, tables);
    print("I am DIFFERENT, I am QueueWaiterAgent");
  }
  
  public void setOrderQueue(OrderQueue orderQueue){
    this.orderQueue = orderQueue;
  }

  public void sendOrderToCook(Order order){
    orderQueue.insert(order);
  }
}
