package restaurant.agent;

import java.awt.Color;
import java.util.*;
import java.util.concurrent.*;

import astar.*;
import agent.Agent;
import restaurant.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.abstracts.*;
import restaurant.layoutGUI.*;
import restaurant.gui.RestaurantGui;

public class WaiterAgent extends AbstractWaiterAgent {

  public WaiterAgent(String name, AStarTraversal aStar, Restaurant restaurant, TableGui[] tables) {
    super(name, aStar, restaurant, tables);
  }

  public void sendOrderToCook(Order order){
    cook.msgHereIsAnOrder(order);
  }
}
