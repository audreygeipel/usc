package restaurant.interfaces;

import restaurant.*;

public interface Cashier {

  abstract public void msgHereIsBill(Bill bill);
  
  abstract public void msgHereIsMyPayment(Bill bill, int price);
}
