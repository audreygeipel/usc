package restaurant.interfaces;

import restaurant.*;

public interface Cook {

  abstract public void msgHereIsAnOrder(Order order);

  abstract public void msgHereIsYourOrderAndBill(MarketOrder marketOrder, MarketBill marketBill);
}
