package restaurant.interfaces;

import restaurant.*;
import restaurant.layoutGUI.*;

/** Restaurant customer agent. 
 * Comes to the restaurant when he/she becomes hungry.
 * Randomly chooses a menu item and simulates eating 
 * when the food arrives. 
 * Interacts with a waiter only */
public interface Customer {

  /** Sent from GUI to set the customer as hungry */
  abstract public void setHungry();

  abstract public void msgRestaurantIsFull();

  /** Waiter sends this message so the customer knows to sit down 
   * @param waiter the waiter that sent the message
   * @param menu a reference to a menu */
  abstract public void msgFollowMeToTable(Waiter waiter, Menu menu);

  /** Waiter sends this message to take the customer's order */
  abstract public void msgDecided();

  /** Waiter sends this message to take the customer's order */
  abstract public void msgWhatWouldYouLike();

  /** Waiter sends this when the food is ready 
   * @param choice the food that is done cooking for the customer to eat */
  abstract public void msgHereIsYourFoodAndBill(String choice, Bill bill, Cashier cashier);

  abstract public void msgYourChoiceIsNotAvailable(Menu menu);

  /** Timer sends this when the customer has finished eating */
  abstract public void msgDoneEating();

  /** Timer sends this when the customer has finished eating */
  abstract public void msgHereIsYourReceipt();

  abstract public CustomerGui getGuiCustomer();

  abstract public void setTableNum(int num);

  abstract public int getTableNum();
}

