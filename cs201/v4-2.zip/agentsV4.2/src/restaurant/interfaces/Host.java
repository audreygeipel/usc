package restaurant.interfaces;

import restaurant.*;

/** Host agent for restaurant.
 *  Keeps a list of all the waiters and tables.
 *  Assigns new customers to waiters for seating and 
 *  keeps a list of waiting customers.
 *  Interacts with customers and waiters.
 */
public interface Host {

  /** Customer sends this message to be added to the wait list 
   * @param customer customer that wants to be added */
  public void msgIWantToEat(Customer customer);

  public void msgImLeavingWithoutEating(Customer customer);

  /** Waiter sends this message after the customer has left the table 
   * @param tableNum table identification number */
  public void msgTableIsFree(int tableNum);

  public void msgINeedBreak(Waiter waiter); 

  public void msgImBackToWorking(Waiter waiter);
}

