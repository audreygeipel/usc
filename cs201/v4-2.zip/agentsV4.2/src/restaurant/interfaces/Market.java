package restaurant.interfaces;

import restaurant.*;

public interface Market {
  
  public void msgHereIsMyOrder(Cook cook, MarketOrder marketOrder);
}

