package restaurant.interfaces;

import restaurant.*;

public interface Waiter {

  /** Host sends this to give the waiter a new customer.
   * @param customer customer who needs seated.
   * @param tableNum identification number for table */
  public void msgSitCustomerAtTable(Customer customer, int tableNum);

  /** Customer sends this when they are ready.
   * @param customer customer who is ready to order.
   */
  public void msgImReadyToOrder(Customer customer);

  /** Customer sends this when they have decided what they want to eat 
   * @param customer customer who has decided their choice
   * @param choice the food item that the customer chose */
  public void msgHereIsMyChoice(Customer customer, String choice);

  /** Customer sends this when they are done eating.
   * @param customer customer who is leaving the restaurant. */
  public void msgDoneEatingAndLeaving(Customer customer);

  /** Cook sends this when the order is ready.
   * @param tableNum identification number of table whose food is ready
   * @param f is the guiFood object */
  public void msgOrderIsReady(Order order);

  public void msgOrderIsNotAvailable(Order order);

  /** Sent from GUI to control breaks 
   * @param state true when the waiter should go on break and 
   *              false when the waiter should go off break
   *              Is the name onBreak right? What should it be?*/
  public void setBreakStatus(boolean status);

  public void msgGoOnBreak();
}

