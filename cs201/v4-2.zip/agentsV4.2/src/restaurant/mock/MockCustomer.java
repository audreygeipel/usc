package restaurant.mock;

import restaurant.*;
import restaurant.mock.*;
import restaurant.layoutGUI.*;
import restaurant.interfaces.*;

public class MockCustomer extends MockAgent implements Customer  {

	public MockCustomer(String name) {
		super(name);
	}

	public EventLog log = new EventLog();
  
  public int tableNum = 0;

  public void setHungry(){
		log.add(new LoggedEvent("Received message setHungry"));
  }

  public void msgRestaurantIsFull(){
		log.add(new LoggedEvent("Received message msgRestaurantIsFull"));
  }

  public void msgFollowMeToTable(Waiter waiter, Menu menu){
		log.add(new LoggedEvent("Received message msgFollowMeToTable"));
  }

  public void msgDecided(){
		log.add(new LoggedEvent("Received message msgDecided"));
  }

  public void msgWhatWouldYouLike(){
		log.add(new LoggedEvent("Received message msgWhatWouldYouLike"));
  }

  public void msgHereIsYourFoodAndBill(String choice, Bill bill, Cashier cashier){
		log.add(new LoggedEvent("Received message msgHereIsYourFoodAndBill"));
  }

  public void msgYourChoiceIsNotAvailable(Menu menu){
		log.add(new LoggedEvent("Received message msgYourChoiceIsNotAvailable"));
  }

  public void msgDoneEating(){
		log.add(new LoggedEvent("Received message msgDoneEating"));
  }

  public void msgHereIsYourReceipt(){
		log.add(new LoggedEvent("Received message msgHereIsYourReceipt"));
  }

  public CustomerGui getGuiCustomer(){
		log.add(new LoggedEvent("Received message setHungry"));
    return new CustomerGui(null, null, null);
  }

  public void setTableNum(int num){
		log.add(new LoggedEvent("Received message setTableNum"));
    this.tableNum = num;
  }

  public int getTableNum(){
		log.add(new LoggedEvent("Received message getTableNum"));
    return this.tableNum;
  }
}
