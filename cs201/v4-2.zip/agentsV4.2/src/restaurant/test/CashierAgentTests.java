package restaurant.test;

import static org.junit.Assert.*;

import java.util.*;
import java.awt.Color;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import restaurant.*;
import restaurant.mock.*;
import restaurant.agent.*;
import restaurant.interfaces.*;
import restaurant.layoutGUI.FoodGui;

public class CashierAgentTests extends TestCase {

  @Test
  public void testCashierName() {
    CashierAgent cashier = new CashierAgent("Cashier1", null);
    assertEquals("Cashier should have correct name", "Cashier1", cashier.getName());
  }

  @Test
  public void testMsgHereIsBill() {
    CashierAgent cashier = new CashierAgent("Cashier1", null);
    Customer customer = new MockCustomer("Customer1");
    Bill bill = new Bill(customer, 10);

    assertEquals("Cashier should have no bill in his queue", 0, cashier.bills.size());
    cashier.msgHereIsBill(bill);
    assertEquals("Cashier should have 1 bill in his queue", 1, cashier.bills.size());
    assertEquals("New bill's status should be PENDING", cashier.bills.get(bill), CashierAgent.BillStatus.PENDING);
  }

  @Test
  public void testMsgHereIsMyPayment() {
    CashierAgent cashier = new CashierAgent("Cashier1", null);
    MockCustomer customer = new MockCustomer("Customer1");
    Bill bill = new Bill(customer, 10);

    cashier.msgHereIsBill(bill);
    cashier.msgHereIsMyPayment(bill, 10);
    assertEquals("Bill's status should be WAITING_RECEIPT", cashier.bills.get(bill), CashierAgent.BillStatus.WAITING_RECEIPT);
    assertEquals("Bill's payedPrice should be correct", bill.payedPrice, 10);

    cashier.pickAndExecuteAnAction();

    assertEquals("Cashier should change bill's status to DONE", cashier.bills.get(bill), CashierAgent.BillStatus.DONE);
    assertEquals("Customer should not have message msgHereIsYourReceipt", false, customer.log.containsString("msgHereIsYourReceipt"));

    try {
      Thread.sleep(2000);
    } catch (InterruptedException e) {}

    assertEquals("Customer should receive message msgHereIsYourReceipt from cashier", true, customer.log.containsString("msgHereIsYourReceipt"));
  }
}

